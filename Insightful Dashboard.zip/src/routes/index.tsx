import { createFileRoute } from "@tanstack/react-router";
import { FileText, Tag, Download, GitBranch, RefreshCw, Search, Plus } from "lucide-react";
import { Sidebar } from "@/components/vault/Sidebar";
import { StatCard } from "@/components/vault/StatCard";
import { ActivityStatus } from "@/components/vault/ActivityStatus";
import { NoteTypesChart, ParaFoldersChart } from "@/components/vault/Charts";
import { ActivityHeatmap } from "@/components/vault/ActivityHeatmap";
import { TopTags } from "@/components/vault/TopTags";
import { RecentNotes } from "@/components/vault/RecentNotes";

export const Route = createFileRoute("/")({
  component: Dashboard,
});

function Dashboard() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      <main className="flex-1 min-w-0">
        {/* Header */}
        <header className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border">
          <div className="flex items-center justify-between gap-4 px-6 lg:px-8 py-4">
            <div>
              <h1 className="text-xl font-semibold tracking-tight">Dashboard</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Obsidian vault overview · Synced 2 minutes ago</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md border border-border bg-card text-sm text-muted-foreground w-64">
                <Search className="h-3.5 w-3.5" />
                <input
                  type="text"
                  placeholder="Search notes, tags…"
                  className="bg-transparent outline-none flex-1 text-sm placeholder:text-muted-foreground"
                />
                <kbd className="text-[10px] px-1.5 py-0.5 rounded bg-muted border border-border">⌘K</kbd>
              </div>
              <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium border border-border bg-card hover:bg-muted transition-colors">
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh
              </button>
              <button
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
                style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
              >
                <Plus className="h-3.5 w-3.5" />
                New Note
              </button>
            </div>
          </div>
        </header>

        <div className="p-6 lg:p-8 space-y-6 max-w-[1400px]">
          {/* Stats */}
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Total Notes" value={40} delta="+5 this week" trend="up" icon={FileText} accent="primary" spark={[2, 3, 5, 4, 6, 7, 6, 9]} />
            <StatCard label="Total Tags" value={31} delta="+2 this week" trend="up" icon={Tag} accent="success" spark={[5, 6, 6, 7, 7, 8, 9, 9]} />
            <StatCard label="Saved via App" value={10} delta="25% of total" trend="neutral" icon={Download} accent="warning" spark={[1, 2, 2, 3, 4, 6, 7, 10]} />
            <StatCard label="Orphan Notes" value={4} delta="−2 from last week" trend="down" icon={GitBranch} accent="destructive" spark={[8, 7, 7, 6, 5, 5, 4, 4]} />
          </section>

          {/* Status */}
          <ActivityStatus />

          {/* Charts row */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <NoteTypesChart />
            <ParaFoldersChart />
          </section>

          {/* Heatmap */}
          <ActivityHeatmap />

          {/* Tags + Notes */}
          <section className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <TopTags />
            </div>
            <div className="lg:col-span-3">
              <RecentNotes />
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
