const DAYS = ["Mon", "Wed", "Fri"];

function generateCells() {
  const cells: number[] = [];
  for (let i = 0; i < 7 * 18; i++) {
    const r = Math.random();
    cells.push(r < 0.45 ? 0 : r < 0.7 ? 1 : r < 0.85 ? 2 : r < 0.95 ? 3 : 4);
  }
  return cells;
}

const cells = generateCells();

const levelColor = (l: number) => {
  if (l === 0) return "color-mix(in oklab, var(--muted) 80%, transparent)";
  const opacity = [0, 0.25, 0.5, 0.75, 1][l];
  return `color-mix(in oklab, var(--primary) ${opacity * 100}%, var(--card))`;
};

export function ActivityHeatmap() {
  return (
    <div className="rounded-xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-baseline justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold">Note Activity</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Notes saved over the last 18 weeks</p>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <span>Less</span>
          {[0, 1, 2, 3, 4].map((l) => (
            <div key={l} className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: levelColor(l) }} />
          ))}
          <span>More</span>
        </div>
      </div>
      <div className="flex gap-2">
        <div className="flex flex-col justify-between py-0.5 text-[10px] text-muted-foreground">
          {DAYS.map((d) => <div key={d}>{d}</div>)}
        </div>
        <div className="grid grid-flow-col grid-rows-7 gap-1 flex-1">
          {cells.map((level, i) => (
            <div
              key={i}
              className="aspect-square rounded-[3px] transition-transform hover:scale-125"
              style={{ backgroundColor: levelColor(level) }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
