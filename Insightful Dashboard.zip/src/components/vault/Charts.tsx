import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, PieChart, Pie } from "recharts";

const noteTypeData = [
  { name: "Reference", value: 22 },
  { name: "Project", value: 8 },
  { name: "Area", value: 6 },
  { name: "Archive", value: 4 },
];

const paraData = [
  { name: "Areas", value: 3, color: "oklch(0.6 0.2 265)" },
  { name: "Resources", value: 2, color: "oklch(0.7 0.16 195)" },
  { name: "Projects", value: 1, color: "oklch(0.75 0.15 75)" },
];

const typeColors = ["oklch(0.55 0.22 265)", "oklch(0.65 0.2 285)", "oklch(0.7 0.18 200)", "oklch(0.75 0.15 75)"];

const tooltipStyle = {
  backgroundColor: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "8px",
  fontSize: "12px",
  padding: "6px 10px",
  boxShadow: "var(--shadow-elevated)",
};

export function NoteTypesChart() {
  return (
    <div className="rounded-xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="mb-4">
        <h3 className="text-sm font-semibold">Note Types</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Distribution across categories</p>
      </div>
      <div className="h-52">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={noteTypeData} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} />
            <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} />
            <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={48}>
              {noteTypeData.map((_, i) => (
                <Cell key={i} fill={typeColors[i]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function ParaFoldersChart() {
  const total = paraData.reduce((s, d) => s + d.value, 0);
  return (
    <div className="rounded-xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="mb-4">
        <h3 className="text-sm font-semibold">PARA Folders</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Folder breakdown</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="h-44 w-44 relative shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={paraData}
                dataKey="value"
                innerRadius={48}
                outerRadius={78}
                paddingAngle={3}
                strokeWidth={0}
              >
                {paraData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <div className="text-2xl font-semibold tabular-nums">{total}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">folders</div>
          </div>
        </div>
        <div className="flex-1 space-y-2.5">
          {paraData.map((d) => (
            <div key={d.name} className="flex items-center gap-2.5 text-sm">
              <div className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: d.color }} />
              <span className="flex-1 text-foreground">{d.name}</span>
              <span className="tabular-nums text-muted-foreground">{d.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
