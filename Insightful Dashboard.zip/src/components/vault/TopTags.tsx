const tags = [
  { name: "academics", count: 17 },
  { name: "result", count: 12 },
  { name: "bca", count: 6 },
  { name: "mca", count: 6 },
  { name: "cnc", count: 3 },
  { name: "gcode", count: 3 },
  { name: "manufacturing", count: 3 },
  { name: "mcode", count: 3 },
  { name: "school", count: 3 },
  { name: "id", count: 2 },
  { name: "aadhaar", count: 1 },
  { name: "certificate", count: 1 },
];

const max = Math.max(...tags.map((t) => t.count));

export function TopTags() {
  return (
    <div className="rounded-xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-baseline justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold">Top Tags</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Most frequently used</p>
        </div>
        <button className="text-xs text-primary hover:underline">View all</button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => {
          const intensity = 0.4 + (tag.count / max) * 0.6;
          return (
            <button
              key={tag.name}
              className="group inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium border border-transparent hover:border-primary/30 transition-all"
              style={{
                backgroundColor: `color-mix(in oklab, var(--primary) ${intensity * 18}%, var(--card))`,
                color: "var(--primary)",
              }}
            >
              <span>#{tag.name}</span>
              <span className="tabular-nums opacity-60">{tag.count}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
