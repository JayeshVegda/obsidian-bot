import { LucideIcon } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area } from "recharts";

interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  trend?: "up" | "down" | "neutral";
  icon: LucideIcon;
  spark?: number[];
  accent?: "primary" | "success" | "warning" | "destructive";
}

const accentMap = {
  primary: { fg: "var(--primary)", bg: "var(--primary-soft)" },
  success: { fg: "var(--success)", bg: "var(--success-soft)" },
  warning: { fg: "var(--warning)", bg: "var(--warning-soft)" },
  destructive: { fg: "var(--destructive)", bg: "color-mix(in oklab, var(--destructive) 12%, transparent)" },
};

export function StatCard({ label, value, delta, trend = "neutral", icon: Icon, spark, accent = "primary" }: StatCardProps) {
  const colors = accentMap[accent];
  const data = (spark ?? [3, 5, 4, 7, 6, 8, 7, 9]).map((v, i) => ({ i, v }));
  const trendColor = trend === "up" ? "var(--success)" : trend === "down" ? "var(--destructive)" : "var(--muted-foreground)";

  return (
    <div
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30"
      style={{ boxShadow: "var(--shadow-soft)" }}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="mt-1.5 text-3xl font-semibold tabular-nums tracking-tight">{value}</div>
          {delta && (
            <div className="mt-1 text-xs font-medium tabular-nums" style={{ color: trendColor }}>
              {delta}
            </div>
          )}
        </div>
        <div
          className="flex h-9 w-9 items-center justify-center rounded-lg"
          style={{ backgroundColor: colors.bg, color: colors.fg }}
        >
          <Icon className="h-4 w-4" strokeWidth={2.25} />
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-12 opacity-70">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id={`spark-${label}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={colors.fg} stopOpacity={0.4} />
                <stop offset="100%" stopColor={colors.fg} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="v" stroke={colors.fg} strokeWidth={1.75} fill={`url(#spark-${label})`} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
