import { LayoutDashboard, FilePlus, FileText, Settings, RefreshCw, LogOut, Database } from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: FilePlus, label: "Save Note" },
  { icon: FileText, label: "Docs" },
  { icon: Settings, label: "Settings" },
];

export function Sidebar() {
  return (
    <aside className="hidden lg:flex w-60 shrink-0 flex-col border-r border-border bg-card">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-border">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: "var(--gradient-primary)" }}>
          <Database className="h-4.5 w-4.5 text-primary-foreground" strokeWidth={2.5} />
        </div>
        <div>
          <div className="font-semibold text-sm leading-tight">Vault Bot</div>
          <div className="text-[11px] text-muted-foreground">Obsidian sync</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              item.active
                ? "bg-primary-soft text-primary"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="px-3 py-3 border-t border-border space-y-1">
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
          <RefreshCw className="h-4 w-4" />
          Reindex
        </button>
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
        <div className="pt-2 px-3 text-[11px] text-muted-foreground">
          40 notes · 31 tags
        </div>
      </div>
    </aside>
  );
}
