import { FileText, Clock, ChevronRight } from "lucide-react";

interface Note {
  title: string;
  type?: string;
  time: string;
  tags?: string[];
}

const notes: Note[] = [
  { title: "Obsidian Vault Assistant Full Demo Structure", type: "reference", time: "May 13, 09:37 PM", tags: ["obsidian", "vault-management", "knowledge-management"] },
  { title: "Complete CNC Turning Class Notes And Practical Programming Concepts", type: "reference", time: "May 11, 06:45 PM", tags: ["cnc", "cnc-programming", "gcode"] },
  { title: "9 May CNC Turning Rough Programming Practice", type: "reference", time: "May 10, 12:03 PM", tags: ["academics", "cnc", "gcode"] },
  { title: "GCode & MCode Notes", type: "reference", time: "May 10, 11:58 AM", tags: ["academics", "cnc", "gcode"] },
  { title: "Clip Web Page", time: "May 10, 10:56 AM" },
  { title: "Translate to Chinese", time: "May 10, 10:56 AM" },
  { title: "Summarize", time: "May 10, 10:56 AM" },
  { title: "Simplify", time: "May 10, 10:56 AM" },
  { title: "Rewrite as tweet", time: "May 10, 10:56 AM" },
];

export function RecentNotes() {
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-baseline justify-between p-5 pb-3">
        <div>
          <h3 className="text-sm font-semibold">Recent Notes</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Latest activity in your vault</p>
        </div>
        <button className="text-xs text-primary hover:underline">View all</button>
      </div>
      <div className="divide-y divide-border">
        {notes.map((note, i) => (
          <button
            key={i}
            className="w-full flex items-start gap-3 px-5 py-3 text-left hover:bg-muted/50 transition-colors group"
          >
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground group-hover:bg-primary-soft group-hover:text-primary transition-colors">
              <FileText className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                {note.type && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide bg-primary-soft text-primary">
                    {note.type}
                  </span>
                )}
                <span className="text-sm font-medium truncate">{note.title}</span>
              </div>
              <div className="mt-1 flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {note.time}
                </span>
                {note.tags?.map((t) => (
                  <span key={t} className="text-primary">#{t}</span>
                ))}
              </div>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity mt-1.5" />
          </button>
        ))}
      </div>
    </div>
  );
}
