import { CheckCircle2, AlertCircle, Upload } from "lucide-react";

export function ActivityStatus() {
  return (
    <div className="rounded-xl border border-border bg-card p-5" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-baseline justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold">System Status</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Sync and indexing health</p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-[11px] font-medium bg-success-soft" style={{ color: "var(--success)" }}>
          <span className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ backgroundColor: "var(--success)" }} />
          Up to date
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-lg border border-border p-3">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-muted-foreground mb-2">
            <Upload className="h-3 w-3" /> Last note saved
          </div>
          <div className="text-sm font-medium truncate">13-May-26, Obsidian Vault Assistant F…</div>
          <div className="text-xs text-muted-foreground mt-1">May 13, 09:37 PM</div>
        </div>

        <div className="rounded-lg border border-border p-3">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-muted-foreground mb-2">
            <CheckCircle2 className="h-3 w-3" /> Last index push
          </div>
          <div className="text-sm font-medium">May 13, 09:37 PM</div>
          <div className="text-xs mt-1" style={{ color: "var(--success)" }}>Synced successfully</div>
        </div>

        <div className="rounded-lg border border-border p-3">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-muted-foreground mb-2">
            <AlertCircle className="h-3 w-3" /> Last error
          </div>
          <div className="text-sm font-medium text-muted-foreground">None</div>
          <div className="text-xs text-muted-foreground mt-1">Clean for 7 days</div>
        </div>
      </div>
    </div>
  );
}
